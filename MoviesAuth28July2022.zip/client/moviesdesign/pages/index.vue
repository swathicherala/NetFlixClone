<template>
 <div>
  <h1>Movie Collection</h1>
  <movie />
  <home />
 </div>
</template>

<script>
import movie from './movie.vue'
export default {
  name: 'IndexPage',
  components:{
    movie
  }
}
</script>
