<template>
 <div>
  <h1>Movie Collection</h1>
  <home />
 </div>
</template>

<script>
import home from './home.vue'
export default {
  name: 'IndexPage',
  components:{
    home
  }
}
</script>
