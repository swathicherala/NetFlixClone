<template>
    <img class="background" src="../assets/homeimage.jpeg" alt="Aleq">
</template>

<style scoped>
 img.background {
      position: absolute;
      left: 0px;
      top: 0px;
      width: 100%;
      height: 100%;
      filter: blur(3px);
       /* mask-image: linear-gradient(to left,rgb(81, 81, 84), transparent); */
       background: rgba(0,0,0,.4);
    background-image: linear-gradient(
0deg,rgba(0,0,0,.8) 0,transparent 60%,rgba(0,0,0,.8));
   
      }
</style>